@extends('layouts.app', ['activePage' => 'myObjects', 'title' => 'Subastas', 'navName' => 'New object', 'activeButton' => 'laravel'])

@section('content')
</br>
<div class= "container-fluid">
   
        <div class="col-md-12 mr-auto">
        <div class="card">
            <div class="card-header">
                <legend>Añade un nuevo vehiculo</legend>
            </div>
            <div class="content">
                <form method="get" action="/" class="form-horizontal">

                

                    <fieldset>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Nombre</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Nombre" class="form-control" name="nombre">
                            </div>
                            <label class="col-sm-2 control-label">Matrícula</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Matrícula" class="form-control" name="matricula">
                            </div>
                            <label class="col-sm-2 control-label">Tipo de coche</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Tipo de coche" class="form-control" name="tipoCoche">
                            </div>
                            <label class="col-sm-2 control-label">Tipo de coche</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Tipo de coche" class="form-control" name="tipoCoche">
                            </div>
                            <label class="col-sm-2 control-label">Motor</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Motor" class="form-control" name="motor">
                            </div>
                            <label class="col-sm-2 control-label">Marca</label>
                            <div class="col-sm-12">
                                <input type="text" placeholder="Marca" class="form-control" name="marca">
                            </div>

                            <div class="col-sm-12">
                                <label class="form-label" for="customFile">Default file input example</label>
                                <input type="file" class="form-control" id="customFile" />
                            </div>
                        </div>

                       

                    </fieldset>

                   
                </form>

            </div>
        </div>
        </div>
    
</div>
@endsection    