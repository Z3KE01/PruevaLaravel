@extends('layouts.app', ['activePage' => 'myObjects', 'title' => 'Subastas', 'navName' => 'My objects', 'activeButton' => 'laravel'])

@section('content')
</br>
<div class= "container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card table-big-boy">
                <div class="card-header ">
                    <h4 class="card-title">Tus objetos</h4>
                    <p class="card-category"></p>
                    <br>
                </div>
                <div class="card-body table-full-width">
                    <table class="table table-bigboy">
                        <thead>
                            <tr>
                                <th class="text-center">Imagen</th>
                                <th>Nombre</th>
                                <th class="th-description">Matricula</th>
                                <th class="text-right">Tipo de Coche</th>
                                <th class="text-right">Motor</th>
                                <th class="text-right">Marca</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($objetos as $objeto)
                                <tr>
                                    <td>
                                        <div class="img-container">
                                        <img src="../../assets/img/blog-1.jpg" alt="...">
                                        </div>
                                    </td>
                                    <td class="td-name">
                                        {{$objeto-> nombre}}
                                    </td>
                                    <td>
                                        {{$objeto-> matricula}}
                                    </td>
                                    <td class="td-number">{{$objeto-> tipoCoche}}</td>
                                    <td class="td-number">
                                    {{$objeto-> motor}}
                                    </td>
                                    <td class="td-number">
                                    {{$objeto-> marca}}
                                    </td>
                                    <td class="td-actions">
                                        <button type="button" rel="tooltip" data-placement="left" title="" class="btn btn-info btn-link btn-icon" data-original-title="View Post">
                                            <i class="fa fa-image"></i>
                                       </button>
                                        <button type="button" rel="tooltip" data-placement="left" title="" class="btn btn-success btn-link btn-icon" data-original-title="Edit Post">
                                            <i class="fa fa-edit"></i>
                                        </button>
                                        <button type="button" rel="tooltip" data-placement="left" title="" class="btn btn-danger btn-link btn-icon " data-original-title="Remove Post">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <a  href="{{route('page.index', 'myObjects/newObject')}}" class="btn btn-primary btn-fill btn-wd" >Añadir Coche</a>
        </div>
    </div>

</div>
 @endsection
