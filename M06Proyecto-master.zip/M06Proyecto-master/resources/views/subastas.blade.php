@extends('layouts.app', ['activePage' => 'Subastas', 'title' => 'Subastas', 'navName' => 'Subastas', 'activeButton' => 'laravel'])

@section('content')
</br>
<div class= "container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card table-big-boy">
                <div class="card-header ">
                    <h4 class="card-title">Subastas</h4>
                    <p class="card-category"></p>
                    <br>
                </div>
                <div class="card-body table-full-width">
                    <table class="table table-bigboy">
                        <thead>
                            <tr>
                                <th class="text-center">Imagen</th>
                                <th>Marca</th>
                                <th>Modelo</th>
                                <th class="th-description">Motor</th>
                                <th class="text-right">Precio Actual</th>
                                <th class="text-right">Fecha de finalizacion</th>
                                <th class="text-right">Acciones</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($subastas as $subasta)
                            <tr>
                            
                                <td>
                                    <a download={{$subasta->objeto->path}} href={{'uploads/' . $subasta->objeto->path}}><img width="auto" height="100" src={{asset('uploads/' . $subasta->objeto->path)}}></a>
                                </td>
                                <td class="td-name">
                                    {{$subasta->objeto->marca}}
                                </td>
                                <td class="td-name">
                                    {{$subasta->objeto->nombre}}
                                </td>
                                <td>
                                    {{$subasta->objeto->motor}}
                                </td>
                                <td class="td-number">
                                    {{$subasta->subasta->precioActual}}
                                </td>
                                <td class="td-number">
                                    {{$subasta->subasta->fechaFinalizacion}}
                                </td>
                                <td class="td-actions">
                                <form method="POST" action="{{route('insertarPuja')}}" enctype="multipart/form-data" class="form-horizontal">
                                    <input type="hidden" id="idSubasta" name="idSubasta" value="{{$subasta->subasta->idSubasta}}">
                                    @csrf
                                    @if ($subasta->subasta->activa == 0)
                                    <button disabled type="submit" class="btn btn-wd btn-danger btn-outline"><span class="btn-label"><i class="fa fa-times"></i></span>Pujar</button>
                                    @endif
                                    @if ($subasta->subasta->activa == 1)
                                    <button type="submit" class="btn btn-wd btn-success btn-outline"><span class="btn-label"><i class="fa fa-check"></i></span>Pujar</button>
                                    @endif
                                </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
 @endsection
