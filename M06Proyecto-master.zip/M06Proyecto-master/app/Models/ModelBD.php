<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelBD extends Model
{
    use HasFactory;
    protected $table = 'Prova1';
	protected $primaryKey ='IdPersonalitzat';
    protected $fillable=['IdPersonalitzat', 'nom', 'descripcio'];

}
