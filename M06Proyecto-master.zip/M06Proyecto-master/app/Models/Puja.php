<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Puja extends Model
{
    use HasFactory;
    protected $table = 'Puja';
	protected $primaryKey ='idPuja';
    protected $fillable=['idPuja', 'idSubasta', 'precio', 'idUsuario', 'fechaPuja'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function subasta()
    {
        return $this->hasOne(Subasta::class);
    }

}


