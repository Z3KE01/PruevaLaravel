<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Objeto extends Model
{
    use HasFactory;
    protected $table = 'Objeto';
	protected $primaryKey ='idObjeto';
    protected $fillable=['idObjeto', 'nombre', 'matricula', 'tipoCoche', 'motor', 'path', 'marca', 'idUsuario'];

    public function usuario()
    {
        return $this->belongsTo(User::class);
    }

    public function subasta()
    {
        return $this->hasMany(Subasta::class);
    }

}


