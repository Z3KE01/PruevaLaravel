<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subasta extends Model
{
    use HasFactory;
    protected $table = 'Subasta';
	protected $primaryKey ='idSubasta';
    protected $fillable=['idSubasta', 'idSubastador', 'idObjeto', 'pujaMinima', 'precioActual', 'fechaFinalizacion', 'activa'];

    public function subastador()
    {
        return $this->belongsTo(User::class);
    }

    public function objeto()
    {
        return $this->belongsTo(Objeto::class);
    }

    public function puja()
    {
        return $this->belongsTo(Puja::class);
    }

}
