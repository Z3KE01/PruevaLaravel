<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('homepage');
    }

    public function showObjects()
    {
        $objetos =  Controller1::obtenerObjetos();
       
        return view('myObjects', compact('objetos'));
    }

    public function showSubastas()
    {
        $subastas =  Controller1::showAllSubastas();
       
        return view('subastas', compact('subastas'));
    }

    public function newObject()
    {       
        return view('newObject');
    }

    public function insertarPuja()
    {       
        $puja =  Controller1::insertarPuja();

        return view('insertarPuja', compact('puja'));
    }
}
