<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Subasta;
use App\Models\Puja;
use App\Models\Objeto;
use Auth;
use Carbon\Carbon;

class Controller1 extends Controller
{
	public function show($id) {
    	$find = User::findOrFail($id);
    	return $find->toJson();
	}

	public static function showSubastas() {
		$id = Auth::id();
    	$user = User::Where("id", "=",$id)->Where("rol", "=", 1)->get();
		if(count($user) == 0){
			return "pipo";
		}else{
			$subasta = Subasta::Where("idSubastador", "=", $id)->get();
			return $subasta;
		}
	}

	public static function showAllSubastas() {
		$id = Auth::id();
    	$user = User::Where("id", "=",$id)->get();
		if(count($user) == 0){
			return "pipo";
		}else{
			$subasta = Subasta::select('*');
			$s = $subasta->get();
			$pipo = array();
			foreach ($s as $suba) {
				$coche = new Coche();
				$objetoId = $suba->idObjeto;
				$objeto = Objeto::Where("idObjeto", "=", $objetoId);
				$o = $objeto->get();
				$coche->subasta = $suba;
				foreach ($o as $obj) {
				$coche->objeto = $obj;
				}
				array_push($pipo, $coche);
			}
			return $pipo;
		}
	}

	public function showBids() {
		$id = Auth::id();
    	$user = User::Where("id", "=",$id)->Where("rol", "=", 0)->get();
		if(count($user) == 0){
			return "pipo";
		}else{
			$puja = Puja::Where("puja.idUsuario", "=", $id)->join("subasta", "puja.idSubasta", "=", "subasta.idSubasta")->join("objeto", "subasta.idObjeto", "=", "objeto.idObjeto")->select("subasta.*", "objeto.*")->get();
			return $puja->toJson();
		}
	}

	public static function obtenerObjetos(){
		$id = Auth::id();
		$user = User::Where("id", "=",$id)->get();
		if(count($user) == 0){
			return "pipo";
		}else{
			$objeto = Objeto::Where("idUsuario", "=", $id)->get();
			return $objeto;
		}
	}	

	public function insertarObjetos($nombre, $matricula, $tipoCoche, $motor, $path, $marca){
		$id = Auth::id();
		if($id != ''){
			Objeto::insert(['nombre' => $nombre, 'matricula' => $matricula, 'tipoCoche' => $tipoCoche, 'motor' => $motor, 'path' => $path, 'marca' => $marca, 'idUsuario' => $id]);
			return Controller1::obtenerObjetos();
		}else{
			return "registrate crack!";
		}	
	}

	public function insertarObjetoSubasta($idObjeto, $precioInicial, $precioMinimo){
		$id = Auth::id();
		$userQuery = User::Where("id", "=",$id);
		$user = $userQuery->get();
		//$user = User::Where("id", "=",$id)->select("saldo")->get();
		//return $user;
		if(count($user) == 0){
			return "pipo";
		}else{
			$objeto = Objeto::Where("idUsuario", "=", $id)->Where("idObjeto", "=", $idObjeto)->get();
			json_decode($user, true);
			$saldo = $user[0]['saldo'];
			$saldo -= 100;
			if($saldo >= 0){
				$userQuery->update(['saldo' => $saldo]);
				Subasta::insert(['idSubastador' => $id, 'idObjeto' => $idObjeto, 'pujaMinima' => $precioMinimo, 'fechaFinalizacion' => Carbon::now()->toDateString(), 'activa' => true]);
				return "completed";
			}else{
				return "saldo insuficiente";
			}
			
		}
	}	

	public static function insertarPuja(Request $idSubasta){
		$id = Auth::id();
		$userQuery = User::Where("id", "=",$id);
		$user = $userQuery->get();
		$id = $idSubasta->input("idSubasta");
		if(count($user) == 0){
			return "pipo";
		}else{
			json_decode($user, true);
			$saldo = $user[0]['saldo'];
			$subastaQuery = Subasta::Where('idSubasta', '=', $id)->Where('activa', '=', 1);
			$subasta = $subastaQuery->get();
			if(count($subasta) == 0){
				return "no hay subasta a tu casa";
			}else{
			json_decode($subasta, true);
			$saldo -= $subasta[0]['precioActual'];
				if($saldo >= 0){
					return Controller1::comprobarPujas($saldo, $id);
					return "Done";
				}else{
					return "saldo insuficiente";
				}
			}			
		}
	}

	public function bajarPuja($idSubasta){
		$id = Auth::id();
		$userQuery = User::Where("id", "=",$id);
		$user = $userQuery->get();
		$subastaQuery = Subasta::Where('idSubasta', '=', $idSubasta)->Where('activa', '=', 1);
		$subasta = $subastaQuery->get();
		if(count($subasta) == 0){
			return "no hay subasta a tu casa";
		}else{
		json_decode($subasta, true);
		$minimo = $subasta[0]['pujaMinima'];
		$actual = $subasta[0]['precioActual'];
		$actual = $actual * 0.95;
			if($actual > $minimo){
				$subastaQuery->update(['precioActual' => $actual]);
				return "Done";
			}else{
				$subastaQuery->update(['activa' => false]);
				return "puja finalizada sin comprador";
			}
		}			
		
	}

	public static function comprobarPujas($saldo, $idSubasta){
		$id = Auth::id();
		$userQuery = User::Where("id", "=",$id);
		$subastaQuery = Subasta::Where('idSubasta', '=', $idSubasta);
		$superUserQuery = User::Where("rol", "=",2);
		$superUser = $superUserQuery->get();
		$subasta = $subastaQuery->get();
		json_decode($subasta, true);
		json_decode($superUser, true);
		$subastadorQuery = User::Where('id', '=', $subasta[0]['idSubastador']);
		$subastador = $subastadorQuery->get();
		json_decode($superUser, true);
		$userQuery->update(['saldo' => $saldo]);
		$subastaQuery->update(['activa' => false]);
		$ganadorPrecio = $subastador[0]['saldo']+$subasta[0]['precioActual']*0.97+100;
		$beneficio = $superUser[0]['saldo']+$subasta[0]['precioActual']*0.03;
		$subastadorQuery->update(['saldo' => $ganadorPrecio]);
		$superUserQuery->update(['saldo' => $beneficio]);
		Objeto::Where("idUsuario", "=", $subasta[0]['idSubastador'])->Where("idObjeto", "=", $subasta[0]['idObjeto'])->update(['idUsuario' => $id]);
		return redirect()->route('myObjects');
	}
	
}

class Coche {
    public $subasta = null;
    public $objeto = null;
}

//http://localhost:8000/myObjects/newObject/algo&pipo&casa&hola&espania&motorola
//insert into subasta_coches.objeto (nombre, matricula, tipoCoche, motor, `path`, marca, idUsuario) values ("topotamadre", 2,"aaaaaaaa","blum","espania", "marca", 3);
//insert into subasta_coches.subasta (idSubastador, idObjeto, pujaMinima, precioActual, fechaFinalizacion, activa) values (2, 1, 10, 1000, curdate(), 0);
//insert into puja (idSubasta, precio, idUsuario, fechaPuja) values (2, 500, 2, curdate());
