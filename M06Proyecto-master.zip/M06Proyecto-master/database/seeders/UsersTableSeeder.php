<?php
namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('Users')->insert([
            'name' => 'Admin Admin',
            'email' => 'admin@lightbp.com',
            'email_verified_at' => now(),
            'password' => Hash::make('secret'),
            'rol' => 1,
            'created_at' => now(),
            'updated_at' => now()
        ]);

        DB::table('Users')->insert([
            'name' => 'CasaSubastas',
            'email' => 'casasubasta@casasubasta.com',
            'email_verified_at' => now(),
            'password' => Hash::make('secret'),
            'rol' => 2,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
}
