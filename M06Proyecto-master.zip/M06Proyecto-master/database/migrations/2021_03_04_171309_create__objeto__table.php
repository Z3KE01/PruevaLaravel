<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateObjetoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Objeto', function (Blueprint $table) {
            $table->increments('idObjeto');
            $table->string('nombre');
            $table->string('matricula');
            $table->string('tipoCoche');
            $table->string('motor');
            $table->string('path');
            $table->string('marca');
            $table->integer('idUsuario')->unsigned()->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Objeto');
    }
}
