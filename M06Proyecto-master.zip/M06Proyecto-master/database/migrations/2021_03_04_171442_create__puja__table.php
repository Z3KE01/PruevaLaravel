<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePujaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Puja', function (Blueprint $table) {
            $table->increments('idPuja');
            $table->integer('idSubasta')->unsigned()->index();
            $table->double('precio');
            $table->integer('idUsuario')->unsigned()->index();
            $table->date('fechaPuja');            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Puja');
    }
}
