<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubastaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Subasta', function (Blueprint $table) {
            $table->increments('idSubasta');
            $table->integer('idSubastador')->unsigned()->index();
            $table->integer('idObjeto')->unsigned()->index();
            $table->double('pujaMinima');
            $table->double('precioActual');
            $table->date('fechaFinalizacion');     
            $table->boolean('activa');       
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Subasta');
    }
}
